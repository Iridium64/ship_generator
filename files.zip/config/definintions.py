import os
ROOT_DIR = os.path.realpath(os.path.join(os.path.dirname(__file__), '..'))